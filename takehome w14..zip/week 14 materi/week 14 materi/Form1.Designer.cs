﻿namespace week_14_materi
{
    partial class InsertMatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_team = new System.Windows.Forms.Label();
            this.lb_player = new System.Windows.Forms.Label();
            this.lb_minute = new System.Windows.Forms.Label();
            this.lb_type = new System.Windows.Forms.Label();
            this.dgv_1 = new System.Windows.Forms.DataGridView();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.cb_pemain = new System.Windows.Forms.ComboBox();
            this.cb_type = new System.Windows.Forms.ComboBox();
            this.tb_minute = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.dateMatch = new System.Windows.Forms.DateTimePicker();
            this.lb_matchdate = new System.Windows.Forms.Label();
            this.lb_teamaway = new System.Windows.Forms.Label();
            this.cb_teamaway = new System.Windows.Forms.ComboBox();
            this.lb_matchID = new System.Windows.Forms.Label();
            this.lb_teamhome = new System.Windows.Forms.Label();
            this.cb_teamhome = new System.Windows.Forms.ComboBox();
            this.tb_matchID = new System.Windows.Forms.TextBox();
            this.btn_insert = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_team
            // 
            this.lb_team.AutoSize = true;
            this.lb_team.Location = new System.Drawing.Point(901, 287);
            this.lb_team.Name = "lb_team";
            this.lb_team.Size = new System.Drawing.Size(66, 25);
            this.lb_team.TabIndex = 0;
            this.lb_team.Text = "Team";
            // 
            // lb_player
            // 
            this.lb_player.AutoSize = true;
            this.lb_player.Location = new System.Drawing.Point(901, 336);
            this.lb_player.Name = "lb_player";
            this.lb_player.Size = new System.Drawing.Size(73, 25);
            this.lb_player.TabIndex = 1;
            this.lb_player.Text = "Player";
            // 
            // lb_minute
            // 
            this.lb_minute.AutoSize = true;
            this.lb_minute.Location = new System.Drawing.Point(900, 228);
            this.lb_minute.Name = "lb_minute";
            this.lb_minute.Size = new System.Drawing.Size(77, 25);
            this.lb_minute.TabIndex = 2;
            this.lb_minute.Text = "Minute";
            // 
            // lb_type
            // 
            this.lb_type.AutoSize = true;
            this.lb_type.Location = new System.Drawing.Point(900, 399);
            this.lb_type.Name = "lb_type";
            this.lb_type.Size = new System.Drawing.Size(60, 25);
            this.lb_type.TabIndex = 3;
            this.lb_type.Text = "Type";
            this.lb_type.Click += new System.EventHandler(this.lb_type_Click);
            // 
            // dgv_1
            // 
            this.dgv_1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_1.Location = new System.Drawing.Point(56, 225);
            this.dgv_1.Name = "dgv_1";
            this.dgv_1.RowHeadersWidth = 82;
            this.dgv_1.RowTemplate.Height = 33;
            this.dgv_1.Size = new System.Drawing.Size(799, 806);
            this.dgv_1.TabIndex = 4;
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(1011, 279);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(296, 33);
            this.cb_team.TabIndex = 5;
            this.cb_team.SelectedIndexChanged += new System.EventHandler(this.cb_team_SelectedIndexChanged);
            // 
            // cb_pemain
            // 
            this.cb_pemain.FormattingEnabled = true;
            this.cb_pemain.Location = new System.Drawing.Point(1011, 336);
            this.cb_pemain.Name = "cb_pemain";
            this.cb_pemain.Size = new System.Drawing.Size(296, 33);
            this.cb_pemain.TabIndex = 6;
            this.cb_pemain.SelectedIndexChanged += new System.EventHandler(this.cb_pemain_SelectedIndexChanged);
            // 
            // cb_type
            // 
            this.cb_type.FormattingEnabled = true;
            this.cb_type.Location = new System.Drawing.Point(1010, 399);
            this.cb_type.Name = "cb_type";
            this.cb_type.Size = new System.Drawing.Size(296, 33);
            this.cb_type.TabIndex = 7;
            this.cb_type.SelectedIndexChanged += new System.EventHandler(this.cb_type_SelectedIndexChanged);
            // 
            // tb_minute
            // 
            this.tb_minute.Location = new System.Drawing.Point(1011, 225);
            this.tb_minute.Name = "tb_minute";
            this.tb_minute.Size = new System.Drawing.Size(295, 31);
            this.tb_minute.TabIndex = 8;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(906, 458);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(181, 47);
            this.btn_add.TabIndex = 9;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1106, 458);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(181, 47);
            this.btn_delete.TabIndex = 10;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // dateMatch
            // 
            this.dateMatch.Location = new System.Drawing.Point(759, 86);
            this.dateMatch.Name = "dateMatch";
            this.dateMatch.Size = new System.Drawing.Size(399, 31);
            this.dateMatch.TabIndex = 11;
            this.dateMatch.ValueChanged += new System.EventHandler(this.dateMatch_ValueChanged);
            // 
            // lb_matchdate
            // 
            this.lb_matchdate.AutoSize = true;
            this.lb_matchdate.Location = new System.Drawing.Point(619, 88);
            this.lb_matchdate.Name = "lb_matchdate";
            this.lb_matchdate.Size = new System.Drawing.Size(122, 25);
            this.lb_matchdate.TabIndex = 12;
            this.lb_matchdate.Text = "Match Date";
            // 
            // lb_teamaway
            // 
            this.lb_teamaway.AutoSize = true;
            this.lb_teamaway.Location = new System.Drawing.Point(619, 142);
            this.lb_teamaway.Name = "lb_teamaway";
            this.lb_teamaway.Size = new System.Drawing.Size(124, 25);
            this.lb_teamaway.TabIndex = 13;
            this.lb_teamaway.Text = "Team Away";
            // 
            // cb_teamaway
            // 
            this.cb_teamaway.FormattingEnabled = true;
            this.cb_teamaway.Location = new System.Drawing.Point(759, 142);
            this.cb_teamaway.Name = "cb_teamaway";
            this.cb_teamaway.Size = new System.Drawing.Size(296, 33);
            this.cb_teamaway.TabIndex = 14;
            this.cb_teamaway.SelectionChangeCommitted += new System.EventHandler(this.cb_teamaway_SelectedIndexChanged);
            // 
            // lb_matchID
            // 
            this.lb_matchID.AutoSize = true;
            this.lb_matchID.Location = new System.Drawing.Point(51, 92);
            this.lb_matchID.Name = "lb_matchID";
            this.lb_matchID.Size = new System.Drawing.Size(97, 25);
            this.lb_matchID.TabIndex = 15;
            this.lb_matchID.Text = "Match ID";
            // 
            // lb_teamhome
            // 
            this.lb_teamhome.AutoSize = true;
            this.lb_teamhome.Location = new System.Drawing.Point(51, 145);
            this.lb_teamhome.Name = "lb_teamhome";
            this.lb_teamhome.Size = new System.Drawing.Size(128, 25);
            this.lb_teamhome.TabIndex = 16;
            this.lb_teamhome.Text = "Team Home";
            // 
            // cb_teamhome
            // 
            this.cb_teamhome.FormattingEnabled = true;
            this.cb_teamhome.Location = new System.Drawing.Point(195, 142);
            this.cb_teamhome.Name = "cb_teamhome";
            this.cb_teamhome.Size = new System.Drawing.Size(296, 33);
            this.cb_teamhome.TabIndex = 17;
            this.cb_teamhome.SelectionChangeCommitted += new System.EventHandler(this.cb_teamhome_SelectedIndexChanged);
            // 
            // tb_matchID
            // 
            this.tb_matchID.Enabled = false;
            this.tb_matchID.Location = new System.Drawing.Point(195, 88);
            this.tb_matchID.Name = "tb_matchID";
            this.tb_matchID.Size = new System.Drawing.Size(295, 31);
            this.tb_matchID.TabIndex = 18;
            // 
            // btn_insert
            // 
            this.btn_insert.Location = new System.Drawing.Point(1011, 512);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(173, 43);
            this.btn_insert.TabIndex = 19;
            this.btn_insert.Text = "Insert";
            this.btn_insert.UseVisualStyleBackColor = true;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // InsertMatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1640, 1065);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.tb_matchID);
            this.Controls.Add(this.cb_teamhome);
            this.Controls.Add(this.lb_teamhome);
            this.Controls.Add(this.lb_matchID);
            this.Controls.Add(this.cb_teamaway);
            this.Controls.Add(this.lb_teamaway);
            this.Controls.Add(this.lb_matchdate);
            this.Controls.Add(this.dateMatch);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.tb_minute);
            this.Controls.Add(this.cb_type);
            this.Controls.Add(this.cb_pemain);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.dgv_1);
            this.Controls.Add(this.lb_type);
            this.Controls.Add(this.lb_minute);
            this.Controls.Add(this.lb_player);
            this.Controls.Add(this.lb_team);
            this.Name = "InsertMatch";
            this.Text = "Insert Match";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_team;
        private System.Windows.Forms.Label lb_player;
        private System.Windows.Forms.Label lb_minute;
        private System.Windows.Forms.Label lb_type;
        private System.Windows.Forms.DataGridView dgv_1;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.ComboBox cb_pemain;
        private System.Windows.Forms.ComboBox cb_type;
        private System.Windows.Forms.TextBox tb_minute;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.DateTimePicker dateMatch;
        private System.Windows.Forms.Label lb_matchdate;
        private System.Windows.Forms.Label lb_teamaway;
        private System.Windows.Forms.ComboBox cb_teamaway;
        private System.Windows.Forms.Label lb_matchID;
        private System.Windows.Forms.Label lb_teamhome;
        private System.Windows.Forms.ComboBox cb_teamhome;
        private System.Windows.Forms.TextBox tb_matchID;
        private System.Windows.Forms.Button btn_insert;
    }
}

