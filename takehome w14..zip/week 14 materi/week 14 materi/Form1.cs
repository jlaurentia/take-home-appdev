﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace week_14_materi
{
    public partial class InsertMatch : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable teamA = new DataTable();
        DataTable teamH = new DataTable();
        DataTable dtTeam = new DataTable();
        DataTable dtPlayer = new DataTable();
        DataTable dtKejadian = new DataTable();
        DataTable dtType = new DataTable();
        DataTable dtAll = new DataTable();
        DataTable dtlastmatchdate = new DataTable();
        DataTable dtCountMatch = new DataTable();
        DataTable dtMinute = new DataTable();
        DataTable inputan = new DataTable();
        DataTable dtDipilih = new DataTable();
        DataTable dtinsert = new DataTable();
        DataTable dt = new DataTable();
        public InsertMatch()
        {
            InitializeComponent();
        }
        string sqlQuery;
        string tanggaldipilih;

        private void Form1_Load(object sender, EventArgs e)
        {

            sqlConnect = new MySqlConnection($"server=localhost;uid=root;pwd=abcde12345;database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            sqlQuery = "SELECT team_name, team_id FROM team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(teamA);
            sqlDataAdapter.Fill(teamH);


            sqlDataAdapter.Fill(dtTeam);
            cb_teamhome.DataSource = teamH;
            cb_teamaway.DataSource = teamA;

            cb_teamhome.ValueMember = "team_id";
            cb_teamhome.DisplayMember = "team_name";

            cb_teamaway.ValueMember = "team_id";
            cb_teamaway.DisplayMember = "team_name";

            cb_team.DataSource = dtTeam;
            cb_team.ValueMember = "team_id";
            cb_team.DisplayMember = "team_name"; // yg muncul di tulisan awal combobox

            dtType = new DataTable();
            dtType.Columns.Add("type_id");
            dtType.Columns.Add("type_name");
            dtMinute.Columns.Add("Minute");
            dtType.Rows.Add("GO", "GOAL");
            dtType.Rows.Add("GP", "GOAL PENALTY");
            dtType.Rows.Add("GW", "OWN GOAL");
            dtType.Rows.Add("CR", "RED CARD");
            dtType.Rows.Add("CY", "YELLOW CARD");
            dtType.Rows.Add("PM", "PENALTY MISS");

            cb_type.DataSource = dtType;
            cb_type.DisplayMember = "type_id";
            cb_type.ValueMember = "type_id";

            dtKejadian.Columns.Add("Minute");
            dtKejadian.Columns.Add("Team");
            dtKejadian.Columns.Add("Player");
            dtKejadian.Columns.Add("Type");

            dtinsert.Columns.Add("minute");
            dtinsert.Columns.Add("team_id");
            dtinsert.Columns.Add("player_id");
            dtinsert.Columns.Add("type");

            cb_teamaway.SelectedIndex = 0;
            cb_teamhome.SelectedIndex = 1;
            cb_team.Text = "";
            cb_pemain.Text = "";
            cb_type.Text = "";
            tb_minute.Clear();

        }

        private void cb_team_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                dtPlayer = new DataTable();
                sqlQuery = $"select player_name, player_id from player where team_id = '{cb_team.SelectedValue}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtPlayer);

                cb_pemain.DataSource = dtPlayer;
                cb_pemain.DisplayMember = "player_name";
                cb_pemain.ValueMember = "player_id";


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        int goalHome = 0;
        int goalAway = 0;

        private void cb_pemain_SelectedIndexChanged(object sender, EventArgs e)
        {
            sqlQuery = $"SELECT * FROM dmatch WHERE player_id = '{cb_pemain.SelectedValue.ToString()}' AND team_id = '{cb_team.SelectedValue.ToString()}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtPlayer);
            //cb_pemain.DataSource = dtKejadian;
            //dgv_1.DataSource = dtKejadian;

        }

        private void cb_type_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (tb_minute.Text == "" || cb_team.Text == "" || cb_pemain.Text == "" || cb_type.Text == "" || tb_matchID.Text == "")
            {
                MessageBox.Show("Masukkan data yang lengkap!");
            }
            else
            {
                dtKejadian.Rows.Add(tb_minute.Text, cb_team.Text, cb_pemain.Text, $"{cb_type.SelectedValue}");
                if (cb_type.Text == "GO" || cb_type.Text == "GP")
                {
                    if (cb_teamhome.Text == cb_team.Text)
                    {
                        goalHome++;
                    }
                    else
                    {
                        goalAway++;
                    }
                }
                else if (cb_type.Text == "GW")
                {
                    if (cb_teamhome.Text == cb_team.Text)
                    {
                        goalAway++;
                    }
                    else
                    {
                        goalAway++;
                    }



                }
                dgv_1.DataSource = dtKejadian;
                dtinsert.Rows.Add(tb_minute.Text, cb_team.SelectedValue, cb_pemain.SelectedValue, cb_type.Text);
                cb_type.Text = "";
                tb_minute.Clear();


            }
        }

        private void lb_type_Click(object sender, EventArgs e)
        {

        }

        private void dateMatch_ValueChanged(object sender, EventArgs e)
        {
            try
            {
                sqlQuery = "select match_date from `match` order by match_date desc limit 1";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtlastmatchdate = new DataTable();
                sqlDataAdapter.Fill(dtlastmatchdate);

                if (dtlastmatchdate.Rows.Count > 0)
                {
                    DateTime lastmatchdate = Convert.ToDateTime(dtlastmatchdate.Rows[0]["match_date"]);
                    DateTime tanggaldipilih = dateMatch.Value;
                    if (tanggaldipilih < lastmatchdate)
                    {
                        MessageBox.Show("Pilih tanggal setelah tanggal pertandingan terakhir");
                    }
                    else
                    {

                        string year = tanggaldipilih.Year.ToString();
                        try
                        {

                            sqlQuery = $"select IFNULL(count(*), 0) as match_count from `match` where YEAR(match_date) = '{tanggaldipilih.Year}';";
                            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                            dtCountMatch = new DataTable();
                            sqlDataAdapter.Fill(dtCountMatch);
                            int matchcount = Convert.ToInt32(dtCountMatch.Rows[0]["match_count"]) + 1;
                            string matchNumber = matchcount.ToString("000");
                            tb_matchID.Text = $"{year}{matchNumber}";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }

                    }
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void cb_teamhome_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cb_teamhome.SelectedIndex == cb_teamaway.SelectedIndex)
            {
                MessageBox.Show("Team tidak boleh sama");

            }
            else
            {
                dtDipilih = new DataTable();
                sqlQuery = $"select team_name, team_id from team where team_id = '{cb_teamhome.SelectedValue}' OR team_id = '{cb_teamaway.SelectedValue}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtDipilih);

                cb_team.DataSource = dtDipilih;
                cb_team.DisplayMember = "team_name";
                cb_team.ValueMember = "team_id";
                cb_team.Text = "";
                cb_type.Text = "";

            }


        }
        private void cb_teamaway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_teamaway.SelectedIndex == cb_teamhome.SelectedIndex)
            {
                MessageBox.Show("Team tidak boleh sama");

            }
            else
            {

                dtDipilih = new DataTable();
                sqlQuery = $"select team_name, team_id from team where team_id = '{cb_teamhome.SelectedValue}' OR team_id = '{cb_teamaway.SelectedValue}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtDipilih);

                cb_team.DataSource = dtDipilih;
                cb_team.DisplayMember = "team_name";
                cb_team.ValueMember = "team_id";
                cb_team.Text = "";
                cb_type.Text = "";
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow tampilan = dgv_1.CurrentRow;
            int index = 0;

            if (dgv_1.Rows.Count != 0)
            {
                for (int i = 0; i < dtKejadian.Rows.Count; i++)
                {
                    if (dtKejadian.Rows[i][0].ToString().Contains(tampilan.Cells[0].Value.ToString()))
                    {
                        index = i;
                    }

                }
                if (tampilan.Cells[2].Value.ToString() == "GO" || tampilan.Cells[2].Value.ToString() == "GP")
                {
                    if (cb_teamhome.Text == cb_team.Text)
                    {
                        goalHome--;
                    }
                    else
                    {
                        goalAway--;
                    }
                }
                else if (tampilan.Cells[2].Value.ToString() == "GW")
                {
                    if (cb_teamhome.Text == cb_team.Text)
                    {
                        goalAway--;
                    }
                    else
                    {
                        goalHome--;
                    }
                }
                dtKejadian.Rows.RemoveAt(index);
                dtinsert.Rows.RemoveAt(index);
            }

            dgv_1.DataSource = dtKejadian;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Masuk");

            if (dt.Rows.Count > 0 && dtMinute.Rows.Count > 0)
            {
                string matchid = tb_matchID.Text;
                string matchdate = dateMatch.Value.ToString("yyyy-MM-dd");
                string teamHomeId = cb_teamhome.SelectedValue.ToString();
                string teamAwayId = cb_teamaway.SelectedValue.ToString();
                string refereeId = "M002";

                try
                {
                    
                    sqlQuery = "INSERT INTO `match` (match_id, match_date, team_home, team_away, goal_home, goal_away, referee_id, `delete`) VALUES (@match_id, @match_date, @team_home, @team_away, @goal_home, @goal_away, @referee_id, 0)";
                    sqlConnect.Open();
                    sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                    sqlCommand.Parameters.AddWithValue("@match_id", matchid);
                    sqlCommand.Parameters.AddWithValue("@match_date", matchdate);
                    sqlCommand.Parameters.AddWithValue("@team_home", teamHomeId);
                    sqlCommand.Parameters.AddWithValue("@team_away", teamAwayId);
                    sqlCommand.Parameters.AddWithValue("@goal_home", goalHome); 
                    sqlCommand.Parameters.AddWithValue("@goal_away", goalAway); 
                    sqlCommand.Parameters.AddWithValue("@referee_id", refereeId);
                    sqlCommand.ExecuteNonQuery();

               
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        DataRow row = dt.Rows[i];
                        DataRow minuteRow = dtMinute.Rows[i];
                        string teamId = row["Team"].ToString();
                        string playerId = row["Player"].ToString();

                        sqlQuery = "INSERT INTO dmatch (match_id, minute, team_id, player_id, type, `delete`) " +
                                   "VALUES (@match_id, @minute, @team_id, @player_id, @type, 0)";
                        sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                        sqlCommand.Parameters.AddWithValue("@match_id", matchid);
                        sqlCommand.Parameters.AddWithValue("@minute", minuteRow["minute"]);
                        sqlCommand.Parameters.AddWithValue("@team_id", teamId);
                        sqlCommand.Parameters.AddWithValue("@player_id", playerId);
                        sqlCommand.Parameters.AddWithValue("@type", row["Type"]);
                        sqlCommand.ExecuteNonQuery();
                    }

                    MessageBox.Show("Data inserted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (sqlConnect != null && sqlConnect.State == System.Data.ConnectionState.Open)
                    {
                        sqlConnect.Close();
                    }
                }
            }
            else
            {
                MessageBox.Show("Masukkan data yang lengkap!");
            }
        }
    }
}

