﻿namespace take_home_w8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_produk = new System.Windows.Forms.DataGridView();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.lb_total = new System.Windows.Forms.Label();
            this.tb_sub = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.pnl_tshirt = new System.Windows.Forms.Panel();
            this.pBox_3 = new System.Windows.Forms.PictureBox();
            this.pBox_2 = new System.Windows.Forms.PictureBox();
            this.pBox_1 = new System.Windows.Forms.PictureBox();
            this.pnl_pants = new System.Windows.Forms.Panel();
            this.pBox_9 = new System.Windows.Forms.PictureBox();
            this.pBox_8 = new System.Windows.Forms.PictureBox();
            this.pBox_7 = new System.Windows.Forms.PictureBox();
            this.pnl_shirt = new System.Windows.Forms.Panel();
            this.pBox_6 = new System.Windows.Forms.PictureBox();
            this.pBox_5 = new System.Windows.Forms.PictureBox();
            this.pBox_4 = new System.Windows.Forms.PictureBox();
            this.pnl_longpants = new System.Windows.Forms.Panel();
            this.pBox_12 = new System.Windows.Forms.PictureBox();
            this.pBox_11 = new System.Windows.Forms.PictureBox();
            this.pBox_10 = new System.Windows.Forms.PictureBox();
            this.pnl_shoes = new System.Windows.Forms.Panel();
            this.pBox_15 = new System.Windows.Forms.PictureBox();
            this.pBox_14 = new System.Windows.Forms.PictureBox();
            this.pBox_13 = new System.Windows.Forms.PictureBox();
            this.lb_pboxkiri = new System.Windows.Forms.Label();
            this.lb_hargakiri = new System.Windows.Forms.Label();
            this.btn_addkiri = new System.Windows.Forms.Button();
            this.btn_addtgh = new System.Windows.Forms.Button();
            this.lb_hargatengah = new System.Windows.Forms.Label();
            this.lb_pboxtgh = new System.Windows.Forms.Label();
            this.btn_addkanan = new System.Windows.Forms.Button();
            this.lb_hargakanan = new System.Windows.Forms.Label();
            this.lb_pboxkanan = new System.Windows.Forms.Label();
            this.pnl_Others = new System.Windows.Forms.Panel();
            this.tb_priceothers = new System.Windows.Forms.TextBox();
            this.lb_itemPrice = new System.Windows.Forms.Label();
            this.tb_nameothers = new System.Windows.Forms.TextBox();
            this.lb_itemName = new System.Windows.Forms.Label();
            this.btn_uploadOthers = new System.Windows.Forms.Button();
            this.lb_upload = new System.Windows.Forms.Label();
            this.pBox_others = new System.Windows.Forms.PictureBox();
            this.btn_addOther = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).BeginInit();
            this.pnl_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_1)).BeginInit();
            this.pnl_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_7)).BeginInit();
            this.pnl_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_4)).BeginInit();
            this.pnl_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_10)).BeginInit();
            this.pnl_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_13)).BeginInit();
            this.pnl_Others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1586, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(174, 36);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(155, 36);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(105, 36);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_produk
            // 
            this.dgv_produk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_produk.Location = new System.Drawing.Point(780, 55);
            this.dgv_produk.Name = "dgv_produk";
            this.dgv_produk.RowHeadersVisible = false;
            this.dgv_produk.RowHeadersWidth = 82;
            this.dgv_produk.RowTemplate.Height = 33;
            this.dgv_produk.Size = new System.Drawing.Size(777, 397);
            this.dgv_produk.TabIndex = 1;
            this.dgv_produk.DoubleClick += new System.EventHandler(this.dgv_produk_DoubleClick);
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(781, 472);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(185, 37);
            this.lb_subtotal.TabIndex = 2;
            this.lb_subtotal.Text = "Sub- Total:";
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(862, 509);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(104, 37);
            this.lb_total.TabIndex = 3;
            this.lb_total.Text = "Total:";
            // 
            // tb_sub
            // 
            this.tb_sub.Location = new System.Drawing.Point(965, 476);
            this.tb_sub.Name = "tb_sub";
            this.tb_sub.Size = new System.Drawing.Size(321, 31);
            this.tb_sub.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(965, 515);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(321, 31);
            this.tb_total.TabIndex = 5;
            // 
            // pnl_tshirt
            // 
            this.pnl_tshirt.Controls.Add(this.pBox_3);
            this.pnl_tshirt.Controls.Add(this.pBox_2);
            this.pnl_tshirt.Controls.Add(this.pBox_1);
            this.pnl_tshirt.Location = new System.Drawing.Point(43, 61);
            this.pnl_tshirt.Name = "pnl_tshirt";
            this.pnl_tshirt.Size = new System.Drawing.Size(659, 302);
            this.pnl_tshirt.TabIndex = 6;
            // 
            // pBox_3
            // 
            this.pBox_3.Image = global::take_home_w8.Properties.Resources.tshirt_1;
            this.pBox_3.Location = new System.Drawing.Point(435, 12);
            this.pBox_3.Name = "pBox_3";
            this.pBox_3.Size = new System.Drawing.Size(197, 274);
            this.pBox_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_3.TabIndex = 2;
            this.pBox_3.TabStop = false;
            // 
            // pBox_2
            // 
            this.pBox_2.Image = global::take_home_w8.Properties.Resources.tshirt_3;
            this.pBox_2.Location = new System.Drawing.Point(228, 12);
            this.pBox_2.Name = "pBox_2";
            this.pBox_2.Size = new System.Drawing.Size(189, 274);
            this.pBox_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_2.TabIndex = 1;
            this.pBox_2.TabStop = false;
            // 
            // pBox_1
            // 
            this.pBox_1.Image = global::take_home_w8.Properties.Resources.tshirt_2;
            this.pBox_1.Location = new System.Drawing.Point(19, 12);
            this.pBox_1.Name = "pBox_1";
            this.pBox_1.Size = new System.Drawing.Size(189, 274);
            this.pBox_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_1.TabIndex = 0;
            this.pBox_1.TabStop = false;
            // 
            // pnl_pants
            // 
            this.pnl_pants.Controls.Add(this.pBox_9);
            this.pnl_pants.Controls.Add(this.pBox_8);
            this.pnl_pants.Controls.Add(this.pBox_7);
            this.pnl_pants.Location = new System.Drawing.Point(40, 83);
            this.pnl_pants.Name = "pnl_pants";
            this.pnl_pants.Size = new System.Drawing.Size(659, 302);
            this.pnl_pants.TabIndex = 8;
            // 
            // pBox_9
            // 
            this.pBox_9.Image = global::take_home_w8.Properties.Resources.pants_3;
            this.pBox_9.Location = new System.Drawing.Point(435, 12);
            this.pBox_9.Name = "pBox_9";
            this.pBox_9.Size = new System.Drawing.Size(197, 274);
            this.pBox_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_9.TabIndex = 2;
            this.pBox_9.TabStop = false;
            // 
            // pBox_8
            // 
            this.pBox_8.Image = global::take_home_w8.Properties.Resources.pants_2;
            this.pBox_8.Location = new System.Drawing.Point(228, 12);
            this.pBox_8.Name = "pBox_8";
            this.pBox_8.Size = new System.Drawing.Size(189, 274);
            this.pBox_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_8.TabIndex = 1;
            this.pBox_8.TabStop = false;
            // 
            // pBox_7
            // 
            this.pBox_7.Image = global::take_home_w8.Properties.Resources.pants_1;
            this.pBox_7.Location = new System.Drawing.Point(19, 12);
            this.pBox_7.Name = "pBox_7";
            this.pBox_7.Size = new System.Drawing.Size(189, 274);
            this.pBox_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_7.TabIndex = 0;
            this.pBox_7.TabStop = false;
            // 
            // pnl_shirt
            // 
            this.pnl_shirt.Controls.Add(this.pBox_6);
            this.pnl_shirt.Controls.Add(this.pBox_5);
            this.pnl_shirt.Controls.Add(this.pBox_4);
            this.pnl_shirt.Location = new System.Drawing.Point(46, 43);
            this.pnl_shirt.Name = "pnl_shirt";
            this.pnl_shirt.Size = new System.Drawing.Size(659, 302);
            this.pnl_shirt.TabIndex = 7;
            // 
            // pBox_6
            // 
            this.pBox_6.Image = global::take_home_w8.Properties.Resources.shirt_2;
            this.pBox_6.Location = new System.Drawing.Point(435, 12);
            this.pBox_6.Name = "pBox_6";
            this.pBox_6.Size = new System.Drawing.Size(197, 274);
            this.pBox_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_6.TabIndex = 2;
            this.pBox_6.TabStop = false;
            // 
            // pBox_5
            // 
            this.pBox_5.Image = global::take_home_w8.Properties.Resources.shirt_3;
            this.pBox_5.Location = new System.Drawing.Point(228, 12);
            this.pBox_5.Name = "pBox_5";
            this.pBox_5.Size = new System.Drawing.Size(189, 274);
            this.pBox_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_5.TabIndex = 1;
            this.pBox_5.TabStop = false;
            // 
            // pBox_4
            // 
            this.pBox_4.Image = global::take_home_w8.Properties.Resources.shirt_1;
            this.pBox_4.Location = new System.Drawing.Point(19, 12);
            this.pBox_4.Name = "pBox_4";
            this.pBox_4.Size = new System.Drawing.Size(189, 274);
            this.pBox_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_4.TabIndex = 0;
            this.pBox_4.TabStop = false;
            // 
            // pnl_longpants
            // 
            this.pnl_longpants.Controls.Add(this.pBox_12);
            this.pnl_longpants.Controls.Add(this.pBox_11);
            this.pnl_longpants.Controls.Add(this.pBox_10);
            this.pnl_longpants.Location = new System.Drawing.Point(37, 110);
            this.pnl_longpants.Name = "pnl_longpants";
            this.pnl_longpants.Size = new System.Drawing.Size(659, 302);
            this.pnl_longpants.TabIndex = 9;
            // 
            // pBox_12
            // 
            this.pBox_12.Image = global::take_home_w8.Properties.Resources.panjang_3;
            this.pBox_12.Location = new System.Drawing.Point(435, 12);
            this.pBox_12.Name = "pBox_12";
            this.pBox_12.Size = new System.Drawing.Size(197, 274);
            this.pBox_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_12.TabIndex = 2;
            this.pBox_12.TabStop = false;
            // 
            // pBox_11
            // 
            this.pBox_11.Image = global::take_home_w8.Properties.Resources.panjang_2;
            this.pBox_11.Location = new System.Drawing.Point(228, 12);
            this.pBox_11.Name = "pBox_11";
            this.pBox_11.Size = new System.Drawing.Size(189, 274);
            this.pBox_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_11.TabIndex = 1;
            this.pBox_11.TabStop = false;
            // 
            // pBox_10
            // 
            this.pBox_10.Image = global::take_home_w8.Properties.Resources.panjang_1;
            this.pBox_10.Location = new System.Drawing.Point(19, 12);
            this.pBox_10.Name = "pBox_10";
            this.pBox_10.Size = new System.Drawing.Size(189, 274);
            this.pBox_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_10.TabIndex = 0;
            this.pBox_10.TabStop = false;
            // 
            // pnl_shoes
            // 
            this.pnl_shoes.Controls.Add(this.pBox_15);
            this.pnl_shoes.Controls.Add(this.pBox_14);
            this.pnl_shoes.Controls.Add(this.pBox_13);
            this.pnl_shoes.Location = new System.Drawing.Point(34, 67);
            this.pnl_shoes.Name = "pnl_shoes";
            this.pnl_shoes.Size = new System.Drawing.Size(659, 302);
            this.pnl_shoes.TabIndex = 10;
            // 
            // pBox_15
            // 
            this.pBox_15.Image = global::take_home_w8.Properties.Resources.spatu_2;
            this.pBox_15.Location = new System.Drawing.Point(435, 12);
            this.pBox_15.Name = "pBox_15";
            this.pBox_15.Size = new System.Drawing.Size(197, 274);
            this.pBox_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_15.TabIndex = 2;
            this.pBox_15.TabStop = false;
            // 
            // pBox_14
            // 
            this.pBox_14.Image = global::take_home_w8.Properties.Resources.spatu_3;
            this.pBox_14.Location = new System.Drawing.Point(228, 12);
            this.pBox_14.Name = "pBox_14";
            this.pBox_14.Size = new System.Drawing.Size(189, 274);
            this.pBox_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_14.TabIndex = 1;
            this.pBox_14.TabStop = false;
            // 
            // pBox_13
            // 
            this.pBox_13.Image = global::take_home_w8.Properties.Resources.spatu_1;
            this.pBox_13.Location = new System.Drawing.Point(19, 12);
            this.pBox_13.Name = "pBox_13";
            this.pBox_13.Size = new System.Drawing.Size(189, 274);
            this.pBox_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_13.TabIndex = 0;
            this.pBox_13.TabStop = false;
            // 
            // lb_pboxkiri
            // 
            this.lb_pboxkiri.AutoSize = true;
            this.lb_pboxkiri.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pboxkiri.Location = new System.Drawing.Point(41, 404);
            this.lb_pboxkiri.Name = "lb_pboxkiri";
            this.lb_pboxkiri.Size = new System.Drawing.Size(184, 31);
            this.lb_pboxkiri.TabIndex = 8;
            this.lb_pboxkiri.Text = "keterangan 1";
            // 
            // lb_hargakiri
            // 
            this.lb_hargakiri.AutoSize = true;
            this.lb_hargakiri.Location = new System.Drawing.Point(89, 453);
            this.lb_hargakiri.Name = "lb_hargakiri";
            this.lb_hargakiri.Size = new System.Drawing.Size(85, 25);
            this.lb_hargakiri.TabIndex = 9;
            this.lb_hargakiri.Text = "harga 1";
            // 
            // btn_addkiri
            // 
            this.btn_addkiri.Location = new System.Drawing.Point(59, 500);
            this.btn_addkiri.Name = "btn_addkiri";
            this.btn_addkiri.Size = new System.Drawing.Size(152, 37);
            this.btn_addkiri.TabIndex = 10;
            this.btn_addkiri.Text = "Add to Chart";
            this.btn_addkiri.UseVisualStyleBackColor = true;
            this.btn_addkiri.Click += new System.EventHandler(this.btn_addkiri_Click);
            // 
            // btn_addtgh
            // 
            this.btn_addtgh.Location = new System.Drawing.Point(296, 500);
            this.btn_addtgh.Name = "btn_addtgh";
            this.btn_addtgh.Size = new System.Drawing.Size(152, 37);
            this.btn_addtgh.TabIndex = 13;
            this.btn_addtgh.Text = "Add to Chart";
            this.btn_addtgh.UseVisualStyleBackColor = true;
            this.btn_addtgh.Click += new System.EventHandler(this.btn_addtgh_Click);
            // 
            // lb_hargatengah
            // 
            this.lb_hargatengah.AutoSize = true;
            this.lb_hargatengah.Location = new System.Drawing.Point(326, 453);
            this.lb_hargatengah.Name = "lb_hargatengah";
            this.lb_hargatengah.Size = new System.Drawing.Size(85, 25);
            this.lb_hargatengah.TabIndex = 12;
            this.lb_hargatengah.Text = "harga 2";
            // 
            // lb_pboxtgh
            // 
            this.lb_pboxtgh.AutoSize = true;
            this.lb_pboxtgh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pboxtgh.Location = new System.Drawing.Point(273, 404);
            this.lb_pboxtgh.Name = "lb_pboxtgh";
            this.lb_pboxtgh.Size = new System.Drawing.Size(184, 31);
            this.lb_pboxtgh.TabIndex = 11;
            this.lb_pboxtgh.Text = "keterangan 2";
            // 
            // btn_addkanan
            // 
            this.btn_addkanan.Location = new System.Drawing.Point(535, 500);
            this.btn_addkanan.Name = "btn_addkanan";
            this.btn_addkanan.Size = new System.Drawing.Size(152, 37);
            this.btn_addkanan.TabIndex = 16;
            this.btn_addkanan.Text = "Add to Chart";
            this.btn_addkanan.UseVisualStyleBackColor = true;
            this.btn_addkanan.Click += new System.EventHandler(this.btn_addkanan_Click);
            // 
            // lb_hargakanan
            // 
            this.lb_hargakanan.AutoSize = true;
            this.lb_hargakanan.Location = new System.Drawing.Point(575, 453);
            this.lb_hargakanan.Name = "lb_hargakanan";
            this.lb_hargakanan.Size = new System.Drawing.Size(85, 25);
            this.lb_hargakanan.TabIndex = 15;
            this.lb_hargakanan.Text = "harga 3";
            // 
            // lb_pboxkanan
            // 
            this.lb_pboxkanan.AutoSize = true;
            this.lb_pboxkanan.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_pboxkanan.Location = new System.Drawing.Point(512, 404);
            this.lb_pboxkanan.Name = "lb_pboxkanan";
            this.lb_pboxkanan.Size = new System.Drawing.Size(184, 31);
            this.lb_pboxkanan.TabIndex = 14;
            this.lb_pboxkanan.Text = "keterangan 3";
            // 
            // pnl_Others
            // 
            this.pnl_Others.Controls.Add(this.tb_priceothers);
            this.pnl_Others.Controls.Add(this.lb_itemPrice);
            this.pnl_Others.Controls.Add(this.tb_nameothers);
            this.pnl_Others.Controls.Add(this.lb_itemName);
            this.pnl_Others.Controls.Add(this.btn_uploadOthers);
            this.pnl_Others.Controls.Add(this.lb_upload);
            this.pnl_Others.Controls.Add(this.pBox_others);
            this.pnl_Others.Controls.Add(this.btn_addOther);
            this.pnl_Others.Location = new System.Drawing.Point(29, 87);
            this.pnl_Others.Margin = new System.Windows.Forms.Padding(4);
            this.pnl_Others.Name = "pnl_Others";
            this.pnl_Others.Size = new System.Drawing.Size(616, 365);
            this.pnl_Others.TabIndex = 50;
            this.pnl_Others.Visible = false;
            this.pnl_Others.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_others_Paint);
            // 
            // tb_priceothers
            // 
            this.tb_priceothers.Enabled = false;
            this.tb_priceothers.Location = new System.Drawing.Point(244, 199);
            this.tb_priceothers.Margin = new System.Windows.Forms.Padding(4);
            this.tb_priceothers.Name = "tb_priceothers";
            this.tb_priceothers.Size = new System.Drawing.Size(201, 31);
            this.tb_priceothers.TabIndex = 53;
            this.tb_priceothers.TextChanged += new System.EventHandler(this.tb_priceothers_TextChanged);
            this.tb_priceothers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_priceothers_KeyPress);
            // 
            // lb_itemPrice
            // 
            this.lb_itemPrice.AutoSize = true;
            this.lb_itemPrice.Location = new System.Drawing.Point(239, 164);
            this.lb_itemPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_itemPrice.Name = "lb_itemPrice";
            this.lb_itemPrice.Size = new System.Drawing.Size(113, 25);
            this.lb_itemPrice.TabIndex = 54;
            this.lb_itemPrice.Text = "Item Price:";
            // 
            // tb_nameothers
            // 
            this.tb_nameothers.Enabled = false;
            this.tb_nameothers.Location = new System.Drawing.Point(244, 114);
            this.tb_nameothers.Margin = new System.Windows.Forms.Padding(4);
            this.tb_nameothers.Name = "tb_nameothers";
            this.tb_nameothers.Size = new System.Drawing.Size(201, 31);
            this.tb_nameothers.TabIndex = 50;
            // 
            // lb_itemName
            // 
            this.lb_itemName.AutoSize = true;
            this.lb_itemName.Location = new System.Drawing.Point(239, 79);
            this.lb_itemName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_itemName.Name = "lb_itemName";
            this.lb_itemName.Size = new System.Drawing.Size(120, 25);
            this.lb_itemName.TabIndex = 52;
            this.lb_itemName.Text = "Item Name:";
            // 
            // btn_uploadOthers
            // 
            this.btn_uploadOthers.Location = new System.Drawing.Point(181, 6);
            this.btn_uploadOthers.Margin = new System.Windows.Forms.Padding(4);
            this.btn_uploadOthers.Name = "btn_uploadOthers";
            this.btn_uploadOthers.Size = new System.Drawing.Size(169, 41);
            this.btn_uploadOthers.TabIndex = 51;
            this.btn_uploadOthers.Text = "Upload";
            this.btn_uploadOthers.UseVisualStyleBackColor = true;
            this.btn_uploadOthers.Click += new System.EventHandler(this.btn_uploadOthers_Click);
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(12, 14);
            this.lb_upload.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(144, 25);
            this.lb_upload.TabIndex = 49;
            this.lb_upload.Text = "Upload Image";
            // 
            // pBox_others
            // 
            this.pBox_others.Location = new System.Drawing.Point(17, 79);
            this.pBox_others.Margin = new System.Windows.Forms.Padding(4);
            this.pBox_others.Name = "pBox_others";
            this.pBox_others.Size = new System.Drawing.Size(199, 251);
            this.pBox_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_others.TabIndex = 48;
            this.pBox_others.TabStop = false;
            // 
            // btn_addOther
            // 
            this.btn_addOther.Enabled = false;
            this.btn_addOther.Location = new System.Drawing.Point(244, 289);
            this.btn_addOther.Margin = new System.Windows.Forms.Padding(4);
            this.btn_addOther.Name = "btn_addOther";
            this.btn_addOther.Size = new System.Drawing.Size(169, 41);
            this.btn_addOther.TabIndex = 55;
            this.btn_addOther.Text = "Add to Cart";
            this.btn_addOther.UseVisualStyleBackColor = true;
            this.btn_addOther.Click += new System.EventHandler(this.btn_addOther_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(1366, 472);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(191, 74);
            this.btn_delete.TabIndex = 51;
            this.btn_delete.Text = "Detele Cart";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1586, 1187);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.pnl_Others);
            this.Controls.Add(this.pnl_shoes);
            this.Controls.Add(this.pnl_longpants);
            this.Controls.Add(this.pnl_pants);
            this.Controls.Add(this.pnl_shirt);
            this.Controls.Add(this.btn_addkanan);
            this.Controls.Add(this.lb_hargakanan);
            this.Controls.Add(this.lb_pboxkanan);
            this.Controls.Add(this.btn_addtgh);
            this.Controls.Add(this.lb_hargatengah);
            this.Controls.Add(this.lb_pboxtgh);
            this.Controls.Add(this.btn_addkiri);
            this.Controls.Add(this.lb_hargakiri);
            this.Controls.Add(this.lb_pboxkiri);
            this.Controls.Add(this.pnl_tshirt);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_sub);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv_produk);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).EndInit();
            this.pnl_tshirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_1)).EndInit();
            this.pnl_pants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_7)).EndInit();
            this.pnl_shirt.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_4)).EndInit();
            this.pnl_longpants.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_10)).EndInit();
            this.pnl_shoes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pBox_15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_13)).EndInit();
            this.pnl_Others.ResumeLayout(false);
            this.pnl_Others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_produk;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.TextBox tb_sub;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.Panel pnl_tshirt;
        private System.Windows.Forms.PictureBox pBox_3;
        private System.Windows.Forms.PictureBox pBox_2;
        private System.Windows.Forms.PictureBox pBox_1;
        private System.Windows.Forms.Panel pnl_shirt;
        private System.Windows.Forms.PictureBox pBox_6;
        private System.Windows.Forms.PictureBox pBox_5;
        private System.Windows.Forms.PictureBox pBox_4;
        private System.Windows.Forms.Panel pnl_pants;
        private System.Windows.Forms.PictureBox pBox_9;
        private System.Windows.Forms.PictureBox pBox_8;
        private System.Windows.Forms.PictureBox pBox_7;
        private System.Windows.Forms.Panel pnl_longpants;
        private System.Windows.Forms.PictureBox pBox_12;
        private System.Windows.Forms.PictureBox pBox_11;
        private System.Windows.Forms.PictureBox pBox_10;
        private System.Windows.Forms.Panel pnl_shoes;
        private System.Windows.Forms.PictureBox pBox_15;
        private System.Windows.Forms.PictureBox pBox_14;
        private System.Windows.Forms.PictureBox pBox_13;
        private System.Windows.Forms.Label lb_pboxkiri;
        private System.Windows.Forms.Label lb_hargakiri;
        private System.Windows.Forms.Button btn_addkiri;
        private System.Windows.Forms.Button btn_addtgh;
        private System.Windows.Forms.Label lb_hargatengah;
        private System.Windows.Forms.Label lb_pboxtgh;
        private System.Windows.Forms.Button btn_addkanan;
        private System.Windows.Forms.Label lb_hargakanan;
        private System.Windows.Forms.Label lb_pboxkanan;
        private System.Windows.Forms.Panel pnl_Others;
        private System.Windows.Forms.TextBox tb_priceothers;
        private System.Windows.Forms.Label lb_itemPrice;
        private System.Windows.Forms.TextBox tb_nameothers;
        private System.Windows.Forms.Label lb_itemName;
        private System.Windows.Forms.Button btn_uploadOthers;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.PictureBox pBox_others;
        private System.Windows.Forms.Button btn_addOther;
        private System.Windows.Forms.Button btn_delete;
    }
}

