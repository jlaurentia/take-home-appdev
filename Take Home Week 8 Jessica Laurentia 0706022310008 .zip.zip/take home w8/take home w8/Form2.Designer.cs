﻿namespace take_home_w8
{
    partial class Secondform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_total = new System.Windows.Forms.TextBox();
            this.tb_sub = new System.Windows.Forms.TextBox();
            this.lb_total = new System.Windows.Forms.Label();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.dgv_produk = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_upload = new System.Windows.Forms.Label();
            this.btn_upload = new System.Windows.Forms.Button();
            this.pBox_others = new System.Windows.Forms.PictureBox();
            this.btn_addOthers = new System.Windows.Forms.Button();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_price = new System.Windows.Forms.Label();
            this.tb_nameOthers = new System.Windows.Forms.TextBox();
            this.tb_priceothers = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).BeginInit();
            this.SuspendLayout();
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(968, 583);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(321, 31);
            this.tb_total.TabIndex = 22;
            // 
            // tb_sub
            // 
            this.tb_sub.Location = new System.Drawing.Point(968, 544);
            this.tb_sub.Name = "tb_sub";
            this.tb_sub.Size = new System.Drawing.Size(321, 31);
            this.tb_sub.TabIndex = 21;
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(865, 577);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(104, 37);
            this.lb_total.TabIndex = 20;
            this.lb_total.Text = "Total:";
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(784, 540);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(185, 37);
            this.lb_subtotal.TabIndex = 19;
            this.lb_subtotal.Text = "Sub- Total:";
            // 
            // dgv_produk
            // 
            this.dgv_produk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_produk.Location = new System.Drawing.Point(779, 84);
            this.dgv_produk.Name = "dgv_produk";
            this.dgv_produk.RowHeadersVisible = false;
            this.dgv_produk.RowHeadersWidth = 82;
            this.dgv_produk.RowTemplate.Height = 33;
            this.dgv_produk.Size = new System.Drawing.Size(832, 437);
            this.dgv_produk.TabIndex = 18;
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1659, 40);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(134, 36);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(219, 44);
            this.shirtToolStripMenuItem.Text = "Shirt";
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(174, 36);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.pantsToolStripMenuItem.Text = "Pants";
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(263, 44);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(155, 36);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.shoesToolStripMenuItem.Text = "Shoes";
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(261, 44);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(105, 36);
            this.othersToolStripMenuItem.Text = "Others";
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(129, 84);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(144, 25);
            this.lb_upload.TabIndex = 23;
            this.lb_upload.Text = "Upload Image";
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(436, 75);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(201, 42);
            this.btn_upload.TabIndex = 24;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // pBox_others
            // 
            this.pBox_others.Location = new System.Drawing.Point(134, 139);
            this.pBox_others.Name = "pBox_others";
            this.pBox_others.Size = new System.Drawing.Size(268, 382);
            this.pBox_others.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_others.TabIndex = 25;
            this.pBox_others.TabStop = false;
            // 
            // btn_addOthers
            // 
            this.btn_addOthers.Location = new System.Drawing.Point(436, 479);
            this.btn_addOthers.Name = "btn_addOthers";
            this.btn_addOthers.Size = new System.Drawing.Size(201, 42);
            this.btn_addOthers.TabIndex = 27;
            this.btn_addOthers.Text = "Add to Cart";
            this.btn_addOthers.UseVisualStyleBackColor = true;
            this.btn_addOthers.Click += new System.EventHandler(this.btn_addOthers_Click);
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Location = new System.Drawing.Point(441, 139);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(120, 25);
            this.lb_name.TabIndex = 26;
            this.lb_name.Text = "Item Name:";
            // 
            // lb_price
            // 
            this.lb_price.AutoSize = true;
            this.lb_price.Location = new System.Drawing.Point(441, 242);
            this.lb_price.Name = "lb_price";
            this.lb_price.Size = new System.Drawing.Size(113, 25);
            this.lb_price.TabIndex = 28;
            this.lb_price.Text = "Item Price:";
            // 
            // tb_nameOthers
            // 
            this.tb_nameOthers.Location = new System.Drawing.Point(445, 177);
            this.tb_nameOthers.Name = "tb_nameOthers";
            this.tb_nameOthers.Size = new System.Drawing.Size(198, 31);
            this.tb_nameOthers.TabIndex = 29;
            this.tb_nameOthers.TextChanged += new System.EventHandler(this.tb_nameOthers_TextChanged);
            // 
            // tb_priceothers
            // 
            this.tb_priceothers.Location = new System.Drawing.Point(445, 281);
            this.tb_priceothers.Name = "tb_priceothers";
            this.tb_priceothers.Size = new System.Drawing.Size(198, 31);
            this.tb_priceothers.TabIndex = 30;
            this.tb_priceothers.TextChanged += new System.EventHandler(this.tb_priceothers_TextChanged);
            this.tb_priceothers.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_priceothers_KeyPress);
            // 
            // Secondform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1659, 822);
            this.Controls.Add(this.tb_priceothers);
            this.Controls.Add(this.tb_nameOthers);
            this.Controls.Add(this.lb_price);
            this.Controls.Add(this.btn_addOthers);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.pBox_others);
            this.Controls.Add(this.btn_upload);
            this.Controls.Add(this.lb_upload);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_sub);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv_produk);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Secondform";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_produk)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_others)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.TextBox tb_sub;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.DataGridView dgv_produk;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.PictureBox pBox_others;
        private System.Windows.Forms.Button btn_addOthers;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_price;
        private System.Windows.Forms.TextBox tb_nameOthers;
        private System.Windows.Forms.TextBox tb_priceothers;
    }
}