﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;

using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace take_home_w8
{
  
    public partial class Form1 : Form
    {
        DataTable dtproduk = new DataTable();
        OpenFileDialog ofd = new OpenFileDialog();

        int rowindex;
        int count;
        int quantity = 0;
        int price;
        int total;
        int subtotalsemua = 0;
        int totalsemua;
        string item;
        public Form1()
        {
            InitializeComponent();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_Others.Visible = true;
            pnl_shirt.Visible = false;
            pnl_tshirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;

            lb_pboxkanan.Visible = false;
            lb_pboxtgh.Visible = false;
            lb_pboxkiri.Visible = false;

            lb_hargakiri.Visible = false;
            lb_hargakanan.Visible = false;
            lb_hargatengah.Visible = false;

            btn_addkiri.Visible = false;
            btn_addtgh.Visible = false;
            btn_addkanan.Visible = false;


            pBox_others.Image = null;
            tb_nameothers.Enabled = false;
            tb_priceothers.Enabled = false;
            btn_addOther.Enabled = false;

            tb_nameothers.Clear();
            tb_priceothers.Clear();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dgv_produk.DataSource = dtproduk;
            dtproduk.Columns.Add("Item Name");
            dtproduk.Columns.Add("Quantity");
            dtproduk.Columns.Add("Price");
            dtproduk.Columns.Add("Total");
           

            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;
    
            
            lb_pboxkanan.Visible = false;
            lb_pboxtgh.Visible = false;
            lb_pboxkiri.Visible = false;

            lb_hargakiri.Visible = false;
            lb_hargakanan.Visible = false;
            lb_hargatengah.Visible = false;

            btn_addkiri.Visible = false;
            btn_addtgh.Visible = false; 
            btn_addkanan.Visible = false;


            pnl_Others.Visible = false;
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = true;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;
            
            lb_pboxkiri.Text = "Kaos Grafika";
            lb_pboxtgh.Text = "Kaos Metona";
            lb_pboxkanan.Text = "Kaos Venusa";

            lb_hargakiri.Text = "Rp 249.000";
            lb_hargatengah.Text = "Rp 359.000";
            lb_hargakanan.Text = "Rp 199.000";
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = true;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;

            lb_pboxkiri.Text = "Kemeja Yahud";
            lb_pboxtgh.Text = "Kemeja Laksika";
            lb_pboxkanan.Text = "Kemeja Slaive";

            lb_hargakiri.Text = "Rp 359.000";
            lb_hargatengah.Text = "Rp 299.000";
            lb_hargakanan.Text = "Rp 459.000";
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = true;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;

            lb_pboxkiri.Text = "Celpen Rockstar";
            lb_pboxtgh.Text = "Celpen Pandaw";
            lb_pboxkanan.Text = "Celpen Tarot";

            lb_hargakiri.Text = "Rp 179.000";
            lb_hargatengah.Text = "Rp 239.000";
            lb_hargakanan.Text = "Rp 199.000";
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = true;
            pnl_shoes.Visible = false;

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;

            lb_pboxkiri.Text = "Celpan Yankees";
            lb_pboxtgh.Text = "Celpan Starboy";
            lb_pboxkanan.Text = "Celpan Brawkley";

            lb_hargakiri.Text = "Rp 599.000";
            lb_hargatengah.Text = "Rp 699.000";
            lb_hargakanan.Text = "Rp 499.000";
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = false;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = true;

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;

            lb_pboxkiri.Text = "Sepatu Sinkle";
            lb_pboxtgh.Text = "Sepatu Wongot";
            lb_pboxkanan.Text = "Sepatu Borknas";

            lb_hargakiri.Text = "Rp 439.000";
            lb_hargatengah.Text = "Rp 529.000";
            lb_hargakanan.Text = "Rp 479.000";
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnl_tshirt.Visible = true;
            pnl_shirt.Visible = false;
            pnl_pants.Visible = false;
            pnl_longpants.Visible = false;
            pnl_shoes.Visible = false;
            string fotosatu = "C:\\takehome\\jewel 1.jpg";
            pBox_1.Image = new Bitmap(fotosatu);
            string fotodua = "C:\\takehome\\jewel 3.jpg";
            pBox_2.Image = new Bitmap(fotodua);
            string fototiga = "C:\\takehome\\jewel 2.jpg";
            pBox_3.Image = new Bitmap(fototiga);

            pnl_Others.Visible = false;

            lb_pboxkanan.Visible = true;
            lb_pboxtgh.Visible = true;
            lb_pboxkiri.Visible = true;

            lb_hargakiri.Visible = true;
            lb_hargakanan.Visible = true;
            lb_hargatengah.Visible = true;

            btn_addkiri.Visible = true;
            btn_addtgh.Visible = true;
            btn_addkanan.Visible = true;

            lb_pboxkiri.Text = "Kalung Masboy";
            lb_pboxtgh.Text = "Gelang Everlast";
            lb_pboxkanan.Text = "Kalung Kendel";

            lb_hargakiri.Text = "Rp 129.000";
            lb_hargatengah.Text = "Rp 99.000";
            lb_hargakanan.Text = "Rp 149.000";
        }

        private void btn_addkiri_Click(object sender, EventArgs e)
        {
            count = 0;
            for (int i = 0; i < dgv_produk.Rows.Count; i++)
            {
                if (dgv_produk.Rows[i].Cells[0].Value != null && dgv_produk.Rows[i].Cells[0].Value.ToString() == lb_pboxkiri.Text)
                {
                    count++;
                    quantity = Convert.ToInt32(dgv_produk.Rows[i].Cells[1].Value) + 1;
                    price = Convert.ToInt32(Regex.Replace(lb_hargakiri.Text, @"[^\d]", ""));
                    total = quantity * price;

                    dgv_produk.Rows[i].Cells[1].Value = quantity;
                    dgv_produk.Rows[i].Cells[3].Value = total;
                    break;
                }
            }

            if (count == 0)
            {
                quantity = 1;
                price = Convert.ToInt32(Regex.Replace(lb_hargakiri.Text, @"[^\d]", ""));
                total = quantity * price;

                dtproduk.Rows.Add(lb_pboxkiri.Text, quantity, price, total);
            }

            // Menghitung subtotal
            subtotalsemua = 0;
            for (int i = 0; i < dtproduk.Rows.Count; i++)
            {
                subtotalsemua += Convert.ToInt32(dtproduk.Rows[i]["Total"]);
            }

            // Menampilkan subtotal
            tb_sub.Text = "Rp " + subtotalsemua.ToString("N0") + ",-";

            // Menghitung total
            totalsemua = subtotalsemua + (10 * subtotalsemua) / 100;

            // Menampilkan total
            tb_total.Text = "Rp " + totalsemua.ToString("N0") + ",-";

            dgv_produk.DataSource = dtproduk;
        }

        

        private void btn_addtgh_Click(object sender, EventArgs e)
        {
            count = 0;
            for (int i = 0; i < dgv_produk.Rows.Count; i++)
            {
                if (dgv_produk.Rows[i].Cells[0].Value != null && dgv_produk.Rows[i].Cells[0].Value.ToString() == lb_pboxtgh.Text)
                {
                    count++;
                    quantity = Convert.ToInt32(dgv_produk.Rows[i].Cells[1].Value) + 1;
                    price = Convert.ToInt32(Regex.Replace(lb_hargatengah.Text, @"[^\d]", ""));
                    total = quantity * price;

                    dgv_produk.Rows[i].Cells[1].Value = quantity;
                    dgv_produk.Rows[i].Cells[3].Value = total;
                    break;
                }
            }

            if (count == 0)
            {
                quantity = 1;
                price = Convert.ToInt32(Regex.Replace(lb_hargatengah.Text, @"[^\d]", ""));
                total = quantity * price;

                dtproduk.Rows.Add(lb_pboxtgh.Text, quantity, price, total);
            }

            // Menghitung subtotal
            subtotalsemua = 0;
            for (int i = 0; i < dtproduk.Rows.Count; i++)
            {
                subtotalsemua += Convert.ToInt32(dtproduk.Rows[i]["Total"]);
            }

            // Menampilkan subtotal
            tb_sub.Text = "Rp " + subtotalsemua.ToString("N0") + ",-";

            // Menghitung total
            totalsemua = subtotalsemua + (10 * subtotalsemua) / 100;

            // Menampilkan total
            tb_total.Text = "Rp " + totalsemua.ToString("N0") + ",-";

            dgv_produk.DataSource = dtproduk;

        }

        private void btn_addkanan_Click(object sender, EventArgs e)
        {
            count = 0;
            for (int i = 0; i < dgv_produk.Rows.Count; i++)
            {
                if (dgv_produk.Rows[i].Cells[0].Value != null && dgv_produk.Rows[i].Cells[0].Value.ToString() == lb_pboxkanan.Text)
                {
                    count++;
                    quantity = Convert.ToInt32(dgv_produk.Rows[i].Cells[1].Value) + 1;
                    price = Convert.ToInt32(Regex.Replace(lb_hargakanan.Text, @"[^\d]", ""));
                    total = quantity * price;

                    dgv_produk.Rows[i].Cells[1].Value = quantity;
                    dgv_produk.Rows[i].Cells[3].Value = total;
                    break;
                }
            }

            if (count == 0)
            {
                quantity = 1;
                price = Convert.ToInt32(Regex.Replace(lb_hargakanan.Text, @"[^\d]", ""));
                total = quantity * price;

                
                dtproduk.Rows.Add(lb_pboxkanan.Text, quantity, price, total);
            }

            // Menghitung subtotal
            subtotalsemua = 0;
            for (int i = 0; i < dtproduk.Rows.Count; i++)
            {
                subtotalsemua += Convert.ToInt32(dtproduk.Rows[i]["Total"]);
            }

            // Menampilkan subtotal
            tb_sub.Text = "Rp " + subtotalsemua.ToString("N0") + ",-";

            // Menghitung total
            totalsemua = subtotalsemua + (10 * subtotalsemua) / 100;

            // Menampilkan total
            tb_total.Text = "Rp " + totalsemua.ToString("N0") + ",-";

            dgv_produk.DataSource = dtproduk;

        }

        private void dgv_produk_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow currentRow = dgv_produk.CurrentRow;
            item = currentRow.Cells[0].Value.ToString();
        }

        private void pnl_others_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_uploadOthers_Click(object sender, EventArgs e)
        {
            ofd.Filter = "All Files (*.jpg)|*.jpg";
            ofd.ShowDialog();
            pBox_others.Image = new Bitmap(ofd.FileName);

            tb_nameothers.Enabled = true;
            tb_priceothers.Enabled = true;
        }

        private void tb_priceothers_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_priceothers_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(tb_nameothers.Text) && !string.IsNullOrWhiteSpace(tb_priceothers.Text))
            {
                btn_addOther.Enabled = true;
            }
            else
            {
                btn_addOther.Enabled = false;
            }
        }

        private void btn_addOther_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(tb_nameothers.Text) && !string.IsNullOrWhiteSpace(tb_priceothers.Text))
            {
                btn_addOther.Enabled = true;
            }
            else
            {
                btn_addOther.Enabled = false;
            }
            count = 0;
            for (int i = 0; i < dgv_produk.Rows.Count; i++)
            {
                if (dgv_produk.Rows[i].Cells[0].Value != null && dgv_produk.Rows[i].Cells[0].Value.ToString() == tb_nameothers.Text)
                {
                    count++;
                    MessageBox.Show("Nama Item tersebut sudah tersedia!");
                    break;
                }
            }
            if (count == 0)
            {
                int quantity = 1; 
                int total = quantity * Convert.ToInt32(tb_priceothers.Text);

                dtproduk.Rows.Add(tb_nameothers.Text, quantity, tb_priceothers.Text, total);
            }


         
            pBox_others.Image = null;
            tb_nameothers.Enabled = false;
            tb_priceothers.Enabled = false;
            btn_addOther.Enabled = false;

            tb_nameothers.Clear();
            tb_priceothers.Clear();

            subtotalsemua = 0;
            for (int i = 0; i < dtproduk.Rows.Count; i++)
            {
                subtotalsemua += Convert.ToInt32(dtproduk.Rows[i]["Total"]);
            }

            // Menampilkan subtotal
            tb_sub.Text = "Rp " + subtotalsemua.ToString("N0") + ",-";

            // Menghitung total
            totalsemua = subtotalsemua + (10 * subtotalsemua) / 100;

            // Menampilkan total
            tb_total.Text = "Rp " + totalsemua.ToString("N0") + ",-";

            dgv_produk.DataSource = dtproduk;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow currentRow = dgv_produk.CurrentRow;
            string item = currentRow.Cells[0].Value.ToString();
            int rowIndex = dgv_produk.CurrentRow.Index;

            if (item != "")
            {
                 quantity = Convert.ToInt32(currentRow.Cells[1].Value); 
                 price = Convert.ToInt32(currentRow.Cells[2].Value); 
                 total = Convert.ToInt32(currentRow.Cells[3].Value); 

                if (quantity > 1)
                {
                    currentRow.Cells[1].Value = quantity - 1; 
                    currentRow.Cells[3].Value = total - price; 
                    subtotalsemua -= price;
                }
                else
                {
                    dgv_produk.Rows.Remove(currentRow); 
                    subtotalsemua -= total; 
                }

                // Tampilkan subtotal
                tb_sub.Text = "Rp " + subtotalsemua.ToString("N0") + ",-";

                // Hitung total
                totalsemua = subtotalsemua + (10 * subtotalsemua) / 100;

                // Tampilkan total
                tb_total.Text = "Rp " + totalsemua.ToString("N0") + ",-";
                dgv_produk.DataSource = dtproduk;
            }

        }

        private void dgv_produk_DoubleClick(object sender, EventArgs e)
        {
            
        }
    }
}
