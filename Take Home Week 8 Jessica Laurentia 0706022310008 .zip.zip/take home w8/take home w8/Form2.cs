﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace take_home_w8
{
    public partial class Secondform : Form
    {
      
        
      
        public Secondform(Form form1, DataTable dtproduk)
        {
           
            InitializeComponent();

        }
        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
           
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void btn_addOthers_Click(object sender, EventArgs e)
        {
         
            
        }

        private void tb_priceothers_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void tb_nameOthers_TextChanged(object sender, EventArgs e)
        {
        }

        private void tb_priceothers_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
